# -*- coding: utf-8 -*-
"""依頼書原本「目次」から依頼NO別の納期回答を読む（読み取り専用）。"""
from __future__ import annotations

import logging
import os

from planning_core.core.request_form_juchu_lookup import normalize_irai_no_key

ENV_REQUEST_FORM_ORIGINAL_DIR = "PM_AI_REQUEST_FORM_ORIGINAL_DIR"
SHEET_NAME = "目次"
COL_IRAI_NO = 0  # A
COL_DELIVERY = 10  # K 納期 → 納期回答
HEADER_SCAN_MAX_ROW = 30
_SKIP_FILES = frozenset({"加工依頼書入力.xlsm"})


def _resolve_original_dir() -> str:
    return (os.environ.get(ENV_REQUEST_FORM_ORIGINAL_DIR) or "").strip()


def _cell(row: tuple, index: int):
    if row is None or index < 0 or index >= len(row):
        return None
    return row[index]


def _header_row_index(rows: list[tuple]) -> int:
    limit = min(len(rows), HEADER_SCAN_MAX_ROW + 1)
    for i in range(limit):
        raw = _cell(rows[i], COL_IRAI_NO)
        text = "" if raw is None else str(raw)
        if "加工依頼" in text:
            return i
    return -1


def _is_data_irai_no(raw) -> bool:
    if raw is None:
        return False
    text = str(raw).strip()
    if not text or text.lower() in ("nan", "none"):
        return False
    if "加工依頼" in text:
        return False
    return True


def load_index_delivery_raw_by_irai_no() -> dict[str, object]:
    """
    依頼NO 正規化キー → 目次 K 列（納期）の生値。

    原本フォルダ配下へは書き込まない。xlsm を read_only で読む。
    ファイルをまたぐときはソート順の先着を採用する（後続ファイルでは上書きしない）。
    """
    dir_path = _resolve_original_dir()
    if not dir_path or not os.path.isdir(dir_path):
        logging.info(
            "回答済み納期ロック: 依頼書原本フォルダが無いため目次納期は読みません。%s=%r",
            ENV_REQUEST_FORM_ORIGINAL_DIR,
            dir_path,
        )
        return {}
    try:
        from openpyxl import load_workbook
    except ImportError as ex:
        logging.warning("回答済み納期ロック: openpyxl 未導入のため目次納期をスキップ: %s", ex)
        return {}

    try:
        names = sorted(os.listdir(dir_path))
    except OSError as ex:
        logging.warning("回答済み納期ロック: 依頼書原本フォルダ一覧失敗: %s", ex)
        return {}

    out: dict[str, object] = {}
    for name in names:
        if not name.lower().endswith(".xlsm"):
            continue
        if name.startswith("~$") or name in _SKIP_FILES:
            continue
        path = os.path.join(dir_path, name)
        if not os.path.isfile(path):
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except Exception as ex:
            logging.warning("回答済み納期ロック: 原本読込スキップ %s: %s", name, ex)
            continue
        try:
            if SHEET_NAME not in wb.sheetnames:
                continue
            ws = wb[SHEET_NAME]
            rows = [tuple(r) for r in ws.iter_rows(values_only=True)]
        except Exception as ex:
            logging.warning("回答済み納期ロック: 目次読込スキップ %s: %s", name, ex)
            continue
        finally:
            try:
                wb.close()
            except Exception:
                pass
        header = _header_row_index(rows)
        if header < 0:
            continue
        file_map: dict[str, object] = {}
        for row in rows[header + 1 :]:
            raw_irai = _cell(row, COL_IRAI_NO)
            if not _is_data_irai_no(raw_irai):
                continue
            key = normalize_irai_no_key(raw_irai)
            if not key:
                continue
            delivery = _cell(row, COL_DELIVERY)
            if delivery is None:
                continue
            if isinstance(delivery, str) and not delivery.strip():
                continue
            file_map[key] = delivery
        for key, delivery in file_map.items():
            if key not in out:
                out[key] = delivery
    logging.info(
        "回答済み納期ロック: 目次納期 lookup 件数=%d dir=%s",
        len(out),
        dir_path,
    )
    return out
