# -*- coding: utf-8 -*-
"""目次に納期回答がある依頼を、後から入った未回答の割り込みで 1 日以上遅らせない。"""
from __future__ import annotations

import fnmatch
import logging
import os
import re
import shutil
import tempfile
from dataclasses import dataclass
from datetime import date, datetime, time

from planning_core.core.request_form_juchu_lookup import (
    load_juchu_input_date_raw_by_irai_no,
    normalize_irai_no_key,
    parent_irai_no_lookup_key,
)
from planning_core.core.request_form_index_delivery_lookup import (
    load_index_delivery_raw_by_irai_no,
)

QTY_EPS = 0.01
_OUTPUT_GLOBS = (
    "計画*.xlsx",
    "計画*.json",
    "人員*.xlsx",
    "人員*.json",
    "production_plan_multi_day_*.xlsx",
    "production_plan_multi_day_*.json",
    "member_schedule_*.xlsx",
    "member_schedule_*.json",
    "結果_配台表.json",
    "結果_配台表.xlsx",
)


@dataclass(frozen=True)
class InputStamp:
    """受注入力日。時刻が無いセルは暦日だけで比較する。"""

    moment: datetime
    has_time: bool


@dataclass(frozen=True)
class DueLockClassification:
    protected_ids: frozenset[str]
    interrupt_ids: frozenset[str]
    delivery_by_task_id: dict[str, date]
    warn_protected_input_date_missing: bool


def parse_calendar_date(val, reference_year: int) -> date | None:
    """納期・加工完了日・配台日を暦日にする。年なし M/d は reference_year。"""
    if val is None or isinstance(val, bool):
        return None
    if isinstance(val, datetime):
        return val.date()
    if isinstance(val, date):
        return val
    if hasattr(val, "to_pydatetime") and not isinstance(val, (str, bytes)):
        try:
            converted = val.to_pydatetime()
        except Exception:
            converted = None
        if isinstance(converted, datetime):
            return converted.date()
        if isinstance(converted, date):
            return converted
    if isinstance(val, float):
        if val != val:
            return None
        return None
    text = str(val).strip()
    if not text or text.lower() in ("nan", "none", "null", "nat"):
        return None
    head = text.split()[0].replace(".", "/")
    ymd = re.fullmatch(r"(\d{4})[/-](\d{1,2})[/-](\d{1,2})", head)
    if ymd:
        try:
            return date(int(ymd.group(1)), int(ymd.group(2)), int(ymd.group(3)))
        except ValueError:
            return None
    md = re.fullmatch(r"(\d{1,2})[/-](\d{1,2})", head)
    if md:
        try:
            return date(int(reference_year), int(md.group(1)), int(md.group(2)))
        except ValueError:
            return None
    return None


def parse_input_stamp(val, reference_year: int) -> InputStamp | None:
    """入力日。0時ちょうど、または時刻表記の無い文字列は日付のみ。"""
    if val is None or isinstance(val, bool):
        return None
    if isinstance(val, datetime):
        has_time = not (
            val.hour == 0 and val.minute == 0 and val.second == 0 and val.microsecond == 0
        )
        return InputStamp(val.replace(tzinfo=None), has_time)
    if isinstance(val, date):
        return InputStamp(datetime.combine(val, time.min), False)
    if hasattr(val, "to_pydatetime") and not isinstance(val, (str, bytes)):
        try:
            converted = val.to_pydatetime()
        except Exception:
            converted = None
        if isinstance(converted, datetime):
            return parse_input_stamp(converted, reference_year)
        if isinstance(converted, date):
            return parse_input_stamp(converted, reference_year)
    day = parse_calendar_date(val, reference_year)
    if day is None:
        return None
    text = str(val)
    clock = _parse_clock(text) if ":" in text else None
    if clock is None or clock == time.min:
        return InputStamp(datetime.combine(day, time.min), False)
    return InputStamp(datetime.combine(day, clock), True)


def _parse_clock(text: str) -> time | None:
    found = re.search(r"(\d{1,2}):(\d{2})(?::(\d{2}))?", text)
    if not found:
        return None
    try:
        return time(int(found.group(1)), int(found.group(2)), int(found.group(3) or 0))
    except ValueError:
        return None


def strictly_after(later: InputStamp, earlier: InputStamp) -> bool:
    """両方に時刻があるときだけ時刻まで見る。同じ暦日は後ではない。"""
    if later.has_time and earlier.has_time:
        return later.moment > earlier.moment
    return later.moment.date() > earlier.moment.date()


def later_input_stamp(left: InputStamp | None, right: InputStamp | None) -> InputStamp | None:
    if left is None:
        return right
    if right is None:
        return left
    if strictly_after(right, left):
        return right
    return left


def _mapped_value(task_id: str, mapping: dict):
    key = normalize_irai_no_key(task_id)
    if key and key in mapping:
        return mapping[key]
    parent = parent_irai_no_lookup_key(task_id)
    if parent and parent in mapping:
        return mapping[parent]
    return None


def classify_task_ids(
    task_ids: list[str],
    *,
    delivery_raw_by_key: dict,
    input_raw_by_key: dict,
    reference_year: int,
) -> DueLockClassification:
    """
    保護: 目次納期が日付になる依頼（枝番は親依頼NOへ落とす）。
    割り込み: 目次納期が無く、入力日が保護側の最大入力日より厳密に後。
    保護側の入力日が1件も無いときは割り込みにしない。
    """
    unique_ids: list[str] = []
    seen: set[str] = set()
    for raw in task_ids:
        tid = str(raw or "").strip()
        if not tid or tid in seen:
            continue
        seen.add(tid)
        unique_ids.append(tid)

    delivery_by_task: dict[str, date] = {}
    input_by_task: dict[str, InputStamp] = {}
    for tid in unique_ids:
        delivery = parse_calendar_date(
            _mapped_value(tid, delivery_raw_by_key), reference_year
        )
        if delivery is not None:
            delivery_by_task[tid] = delivery
        stamp = parse_input_stamp(_mapped_value(tid, input_raw_by_key), reference_year)
        if stamp is not None:
            input_by_task[tid] = stamp

    protected = frozenset(delivery_by_task)
    max_protected_input: InputStamp | None = None
    for tid in protected:
        max_protected_input = later_input_stamp(max_protected_input, input_by_task.get(tid))
    warn_missing = bool(protected) and max_protected_input is None
    interrupts: set[str] = set()
    if max_protected_input is not None:
        for tid in unique_ids:
            if tid in protected:
                continue
            stamp = input_by_task.get(tid)
            if stamp is None:
                continue
            if strictly_after(stamp, max_protected_input):
                interrupts.add(tid)
    return DueLockClassification(
        protected_ids=protected,
        interrupt_ids=frozenset(interrupts),
        delivery_by_task_id=delivery_by_task,
        warn_protected_input_date_missing=warn_missing,
    )


def _trial_sort_key(task: dict) -> tuple:
    raw = task.get("dispatch_trial_order")
    try:
        order = float(raw)
    except (TypeError, ValueError):
        order = 1e18
    if order != order:
        order = 1e18
    seq = task.get("planning_sheet_row_seq")
    try:
        seq_n = int(seq)
    except (TypeError, ValueError):
        seq_n = 10**9
    return (order, seq_n)


def pin_interrupt_trial_orders(task_queue: list, interrupt_ids) -> int:
    """割り込み行の試行順を、それ以外の後ろへ 1..n で付け直す。戻り値は動かした行数。"""
    ids = {str(x).strip() for x in (interrupt_ids or ()) if str(x).strip()}
    if not task_queue or not ids:
        return 0
    others = []
    interrupts = []
    for task in task_queue:
        tid = str(task.get("task_id") or "").strip()
        if tid in ids:
            interrupts.append(task)
        else:
            others.append(task)
    if not interrupts:
        return 0
    others.sort(key=_trial_sort_key)
    interrupts.sort(key=_trial_sort_key)
    task_queue[:] = others + interrupts
    for index, task in enumerate(task_queue, start=1):
        task["dispatch_trial_order"] = index
        task["dispatch_trial_order_from_sheet"] = float(index)
    return len(interrupts)


def exclude_protected_due_shift_ids(task_ids, protected_ids) -> tuple[list[str], list[str]]:
    """納期基準 +1 日の対象から保護依頼を外す。"""
    protected = {str(x).strip() for x in (protected_ids or ()) if str(x).strip()}
    kept: list[str] = []
    skipped: list[str] = []
    for raw in task_ids or ():
        tid = str(raw or "").strip()
        if tid and tid in protected:
            skipped.append(tid)
        elif tid:
            kept.append(tid)
    return kept, skipped


def _qty(val) -> float:
    if val is None or isinstance(val, bool):
        return 0.0
    if isinstance(val, float) and val != val:
        return 0.0
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0


def effective_completion_by_task(rows, reference_year: int) -> dict[str, date]:
    """
    依頼NOごとの実効完了日 = max(加工完了日, 当日配台数量が付いた最終配台日)。
    数量が誤差以下の配台日はシス計に数えない。
    """
    process_complete: dict[str, date] = {}
    last_dispatch: dict[str, date] = {}
    for row in rows or ():
        if not isinstance(row, dict):
            continue
        tid = str(row.get("依頼NO") or "").strip()
        if not tid:
            continue
        completed = parse_calendar_date(row.get("加工完了日"), reference_year)
        if completed is not None:
            prev = process_complete.get(tid)
            if prev is None or completed > prev:
                process_complete[tid] = completed
        if abs(_qty(row.get("当日配台数量"))) <= QTY_EPS:
            continue
        dispatched = parse_calendar_date(row.get("配台日"), reference_year)
        if dispatched is None:
            continue
        prev_d = last_dispatch.get(tid)
        if prev_d is None or dispatched > prev_d:
            last_dispatch[tid] = dispatched
    out: dict[str, date] = {}
    for tid in set(process_complete) | set(last_dispatch):
        options = [d for d in (process_complete.get(tid), last_dispatch.get(tid)) if d is not None]
        if options:
            out[tid] = max(options)
    return out


def slipped_protected_ids(optimistic: dict, pinned: dict, protected_ids) -> list[str]:
    """現行順の実効完了が、割り込み末尾固定の基準より 1 暦日以上遅い保護依頼。"""
    slipped: list[str] = []
    for raw in sorted(protected_ids or ()):
        tid = str(raw or "").strip()
        if not tid:
            continue
        base = pinned.get(tid) if isinstance(pinned, dict) else None
        if base is None:
            continue
        current = optimistic.get(tid) if isinstance(optimistic, dict) else None
        if current is None or (current - base).days >= 1:
            slipped.append(tid)
    return slipped


def completion_misses_shipping_date(effective: date | None, shipping: date) -> bool:
    """実効完了が納期回答（出荷日）当日以降、または未確定なら NG。"""
    if effective is None:
        return True
    return effective >= shipping


def _matches_output_name(name: str) -> bool:
    return any(fnmatch.fnmatch(name, pat) for pat in _OUTPUT_GLOBS)


class OutputSnapshot:
    """段階2成果物のコピー。2回目を捨てるときに戻す。"""

    def __init__(self) -> None:
        self._tmp = tempfile.mkdtemp(prefix="pm_ai_due_lock_")
        self._entries: list[tuple[str, str]] = []
        self._scanned_dirs: set[str] = set()

    def capture(self, directories) -> None:
        seen: set[str] = set()
        for raw_dir in directories or ():
            if not raw_dir or not os.path.isdir(raw_dir):
                continue
            for dirpath, _dirnames, filenames in os.walk(raw_dir):
                self._scanned_dirs.add(os.path.abspath(dirpath))
                for name in filenames:
                    if name.startswith("~$") or not _matches_output_name(name):
                        continue
                    src = os.path.abspath(os.path.join(dirpath, name))
                    if src in seen:
                        continue
                    seen.add(src)
                    stored = os.path.join(self._tmp, str(len(self._entries)))
                    shutil.copy2(src, stored)
                    self._entries.append((src, stored))

    def restore(self) -> None:
        originals = {src for src, _stored in self._entries}
        for directory in self._scanned_dirs:
            if not os.path.isdir(directory):
                continue
            for name in os.listdir(directory):
                if name.startswith("~$") or not _matches_output_name(name):
                    continue
                path = os.path.abspath(os.path.join(directory, name))
                if path in originals:
                    continue
                try:
                    os.remove(path)
                except OSError as ex:
                    logging.warning("回答済み納期ロック: 2回目成果物を削除できません: %s (%s)", path, ex)
        for src, stored in self._entries:
            try:
                os.makedirs(os.path.dirname(src), exist_ok=True)
                shutil.copy2(stored, src)
            except OSError as ex:
                logging.warning("回答済み納期ロック: 1回目成果物を戻せません: %s (%s)", src, ex)

    def cleanup(self) -> None:
        shutil.rmtree(self._tmp, ignore_errors=True)


class Stage2AnsweredDueSession:
    """段階2の1プロセス内で、現行順と割り込み末尾固定を比較する。"""

    def __init__(self) -> None:
        self.active = False
        self.pin = False
        self.protected_ids: frozenset[str] = frozenset()
        self.interrupt_ids: frozenset[str] = frozenset()
        self.delivery_by_task_id: dict[str, date] = {}
        self.completions: dict[str, date] = {}
        self.optimistic: dict[str, date] | None = None
        self.recorded = False
        self.reference_year = date.today().year
        self._classified = False
        self._delivery_raw: dict | None = None
        self._input_raw: dict | None = None

    def begin(self) -> None:
        self.active = True
        self.pin = False
        self.protected_ids = frozenset()
        self.interrupt_ids = frozenset()
        self.delivery_by_task_id = {}
        self.completions = {}
        self.optimistic = None
        self.recorded = False
        self._classified = False
        self._delivery_raw = None
        self._input_raw = None

    def end(self) -> None:
        self.begin()
        self.active = False

    def apply_after_trial_order(self, task_queue: list, reference_year: int) -> None:
        if not self.active:
            return
        self.reference_year = int(reference_year)
        self._ensure_classified(task_queue)
        if not self.pin or not self.interrupt_ids:
            return
        moved = pin_interrupt_trial_orders(task_queue, self.interrupt_ids)
        if moved:
            logging.info(
                "回答済み納期ロック: 割り込み %s 行の配台試行順番を保護依頼の後ろへ固定しました（%s）",
                moved,
                ",".join(sorted(self.interrupt_ids)),
            )

    def _ensure_classified(self, task_queue: list) -> None:
        if self._classified:
            return
        if self._delivery_raw is None:
            self._delivery_raw = load_index_delivery_raw_by_irai_no()
        if self._input_raw is None:
            self._input_raw = load_juchu_input_date_raw_by_irai_no()
        task_ids = [str(t.get("task_id") or "").strip() for t in task_queue or ()]
        classified = classify_task_ids(
            task_ids,
            delivery_raw_by_key=self._delivery_raw,
            input_raw_by_key=self._input_raw,
            reference_year=self.reference_year,
        )
        self.protected_ids = classified.protected_ids
        self.interrupt_ids = classified.interrupt_ids
        self.delivery_by_task_id = classified.delivery_by_task_id
        self._classified = True
        logging.info(
            "回答済み納期ロック: 保護 %s 件、割り込み %s 件",
            len(self.protected_ids),
            len(self.interrupt_ids),
        )
        if classified.warn_protected_input_date_missing:
            logging.warning(
                "回答済み納期ロック: 保護依頼の受注入力日が無いため、割り込みの試行順は下げません。"
            )

    def record_dispatch_frame(self, frame) -> None:
        if not self.active:
            return
        rows = _rows_from_frame(frame)
        self.completions = effective_completion_by_task(rows, self.reference_year)
        self.recorded = True

    def needs_pinned_rerun(self) -> bool:
        return bool(self.active and self.recorded and self.interrupt_ids and self.protected_ids)

    def arm_pinned_rerun(self) -> None:
        self.optimistic = dict(self.completions)
        self.pin = True
        self.completions = {}
        self.recorded = False

    def slipped_ids(self) -> list[str]:
        if self.optimistic is None:
            return []
        return slipped_protected_ids(self.optimistic, self.completions, self.protected_ids)

    def log_adopted_pinned(self) -> None:
        slipped = self.slipped_ids()
        logging.info(
            "回答済み納期ロック: 現行順では保護依頼の完了が基準より1日以上遅いため、"
            "割り込みを後ろにした結果を採用します: %s",
            ",".join(slipped),
        )
        reds = []
        for tid in sorted(self.protected_ids):
            shipping = self.delivery_by_task_id.get(tid)
            if shipping is None:
                continue
            if completion_misses_shipping_date(self.completions.get(tid), shipping):
                reds.append(tid)
        if reds:
            logging.warning(
                "回答済み納期ロック: 割り込みを後ろにしても保護依頼の完了日が"
                "納期回答（出荷日）を満たしません（設備能力不足）: %s",
                ",".join(reds),
            )

    def log_kept_first_pass(self) -> None:
        logging.info(
            "回答済み納期ロック: 現行順でも保護依頼の完了は基準から1日以上遅れていないため、1回目を採用します。"
        )


def _rows_from_frame(frame) -> list:
    if frame is None:
        return []
    if isinstance(frame, list):
        return frame
    to_dict = getattr(frame, "to_dict", None)
    if callable(to_dict):
        try:
            records = to_dict(orient="records")
        except TypeError:
            records = to_dict()
        if isinstance(records, list):
            return records
    return []


stage2_answered_due_session = Stage2AnsweredDueSession()
