# -*- coding: utf-8 -*-
"""
段階2／配台試行（インタラクティブ）の共通オーケストレーション。

- 段階2の正本: ``master`` の工場時間コンテキストのうえで ``_generate_plan_impl()`` を
  オーバーライド無しで実行する（従来 ``generate_plan()`` が担っていた処理）。
  配台失敗ポリシーは配台試行（段階2同一パリティ）と同一（前提未満足のみ致命・他は後ろ倒し）。
- 配台試行の正本: 結果_配台表 JSON の ``rows`` / ``columns`` を読み、タスク DataFrame に
  マージしたうえで ``PM_AI_INTERACTIVE_TRIAL_STAGE2_PARITY=1`` を付与し、
  配台エンジン条件を段階2と同一にした ``_generate_plan_impl`` を実行する。
  不足 JSON のペイロード組み立て・検証失敗時の書き出しもここに集約する。

巨大な配台ループ本体は ``planning_core._core`` の ``_generate_plan_impl`` に残す。
"""
from __future__ import annotations

import json
import os
import traceback
from pathlib import Path

# Runner が設定する環境変数（_core 側で参照）
ENV_INTERACTIVE_TRIAL_STAGE2_PARITY = "PM_AI_INTERACTIVE_TRIAL_STAGE2_PARITY"


def _flush_dispatch_rule_trace_sidecar() -> None:
    try:
        from planning_core.dispatch_rules import trace_recorder

        path = trace_recorder.write_sidecar()
        if path is not None:
            print(f"[dispatch-rules] trace sidecar: {path}", flush=True)
    except Exception as ex:
        print(f"[dispatch-rules] trace sidecar failed: {ex}", flush=True)


def _stage2_output_dirs_for_due_lock(pc) -> list[str]:
    dirs: list[str] = []
    out = getattr(pc, "output_dir", "") or ""
    if out:
        dirs.append(out)
    try:
        from planning_core.dispatch_workspace import resolve_result_dispatch_table_output_dir

        resolved = resolve_result_dispatch_table_output_dir("")
        if resolved:
            dirs.append(resolved)
    except Exception:
        pass
    return dirs


def _rerun_stage2_with_interrupts_pinned(pc, master_abs: str) -> None:
    """現行順の完了が、割り込みを末尾に固定した基準より 1 日以上遅いときだけ 2 回目を残す。"""
    from planning_core.core.answered_due_lock import (
        OutputSnapshot,
        stage2_answered_due_session,
    )

    snap = OutputSnapshot()
    snap.capture(_stage2_output_dirs_for_due_lock(pc))
    try:
        stage2_answered_due_session.arm_pinned_rerun()
        with pc._override_default_factory_hours_from_master(master_abs):
            pc._generate_plan_impl()
        if stage2_answered_due_session.slipped_ids():
            stage2_answered_due_session.log_adopted_pinned()
        else:
            snap.restore()
            stage2_answered_due_session.log_kept_first_pass()
    except Exception:
        snap.restore()
        raise
    finally:
        snap.cleanup()


def run_stage2_generate_plan() -> None:
    """
    段階2標準: マスタの工場時間オーバーライドのうえで ``_generate_plan_impl()`` を実行する。

    目次納期がある依頼より後に受注入力された未回答の割り込みがあるときは、最大もう 1 回、
    割り込みの配台試行順番を後ろに固定して実行し、保護依頼の完了日が 1 日以上遅れるときだけそちらを残す。
    """
    from planning_core import _core as pc
    from planning_core.core.answered_due_lock import stage2_answered_due_session
    from planning_core.dispatch_rules import trace_recorder

    try:
        from planning_core.stage2_network_localize import localize_unc_paths_for_stage2

        localize_unc_paths_for_stage2()
    except Exception as ex:
        print(f"[stage2-localize] スキップ: {ex}", flush=True)

    trace_recorder.reset_trace()
    from planning_core.core.attendance_readiness import require_calendar_json_for_planning_stages

    require_calendar_json_for_planning_stages("段階2")
    master_abs = pc._master_workbook_path_resolved()
    stage2_answered_due_session.begin()
    try:
        with pc._override_default_factory_hours_from_master(master_abs):
            pc._generate_plan_impl()
        if stage2_answered_due_session.needs_pinned_rerun():
            _rerun_stage2_with_interrupts_pinned(pc, master_abs)
    finally:
        stage2_answered_due_session.end()
        _flush_dispatch_rule_trace_sidecar()


def run_interactive_dispatch_trial_from_result_dispatch_json(
    path: Path,
) -> tuple[int, Path | None]:
    """
    配台試行: ``結果_配台表.json`` を入力とし、段階2同一条件で配台を実行する。

    Returns:
        (exit_code, shortage_json_path_or_none)
        exit_code: 0 成功、1 一般失敗、2 usage、3 PlanningValidationError
    """
    path = path.resolve()
    if not path.is_file():
        return 1, None

    from planning_core import _core as pc

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"json read failed: {e}", flush=True)
        return 1, None

    rows = raw.get("rows") if isinstance(raw, dict) else None
    if rows is None:
        print("missing rows array", flush=True)
        return 1, None
    json_columns = raw.get("columns") if isinstance(raw, dict) else None

    os.environ["PM_AI_INTERACTIVE_DISPATCH_TRIAL"] = "1"
    os.environ[ENV_INTERACTIVE_TRIAL_STAGE2_PARITY] = "1"

    from planning_core.dispatch_rules import trace_recorder

    trace_recorder.reset_trace()
    shortage_path = path.with_name("dispatch_trial_shortages.json")

    try:
        print("[dispatch trial] 計画タスクを読み込み、表データをマージ中…", flush=True)
        tasks_df = pc.load_planning_tasks_df()
        try:
            df_src = pc.load_tasks_df()
        except Exception as _e_src:
            print(
                f"[dispatch trial] 加工計画DATA 読込に失敗（静的列の補完のみスキップ）: {_e_src}",
                flush=True,
            )
            df_src = None
        n_fill = pc.fill_interactive_result_dispatch_json_rows_from_planning_sources(
            rows, tasks_df, df_src
        )
        if n_fill:
            print(f"[dispatch trial] 計画入力・加工計画DATA から {n_fill} セルを補完しました。", flush=True)
        merged_df, targets = pc.merge_interactive_result_dispatch_json_into_tasks_df(
            tasks_df, rows
        )
        print("[dispatch trial] 段階2同一条件で配台を実行中…（時間がかかる場合があります）", flush=True)
        master_abs = pc._master_workbook_path_resolved()
        with pc._override_default_factory_hours_from_master(master_abs):
            paths = pc._generate_plan_impl(
                tasks_df_override=merged_df,
                return_output_paths=True,
                interactive_relax_intraday=False,
                interactive_dispatch_targets=targets if targets else None,
                interactive_result_dispatch_json_rows=rows,
                interactive_result_dispatch_json_columns=json_columns
                if isinstance(json_columns, list)
                else None,
            )
        snap = pc.interactive_trial_shortages_snapshot()
        md_snap = pc.interactive_trial_meters_done_snapshot()
        plan_targets = pc.interactive_trial_plan_targets_snapshot()
        shortfall_targets = plan_targets if plan_targets else (targets if targets else None)
        dispatch_qty_shortfall = pc.compute_interactive_trial_dispatch_qty_shortfall(
            shortfall_targets,
            md_snap if md_snap else None,
        )
        _meta_miss = pc.interactive_trial_meta_miss_shortfall_snapshot()
        if _meta_miss:
            _seen_sf = {
                (
                    str(r.get("task_id") or ""),
                    str(r.get("machine_name") or ""),
                    str(r.get("dispatch_date") or ""),
                )
                for r in dispatch_qty_shortfall
            }
            for _row in _meta_miss:
                _k = (
                    str(_row.get("task_id") or ""),
                    str(_row.get("machine_name") or ""),
                    str(_row.get("dispatch_date") or ""),
                )
                if _k not in _seen_sf:
                    dispatch_qty_shortfall.append(_row)
                    _seen_sf.add(_k)
        s3_meta = {}
        try:
            s3_meta = pc.interactive_stage3_last_run_meta_snapshot()
        except Exception:
            s3_meta = {}
        _remaining_at_end = []
        try:
            _remaining_at_end = pc.interactive_trial_remaining_tasks_at_calendar_end_snapshot()
        except Exception:
            _remaining_at_end = []
        _ot_sim = (os.environ.get(pc.ENV_OVERTIME_SIMULATION_JSON) or "").strip()
        _note_base = (
            "配台試行（段階2同一条件）。"
            "配台ループのブロック条件は段階2と同一。"
            "JSON 暦日×数量（interactive_dispatch_targets）がある手動修正試行ではループ内キャップも有効。"
            "致命: 機械カレンダー未作成・勤怠未作成。"
            "勤怠最終日まで未割当のタスクは remaining_tasks_at_calendar_end に載せて試行は続行。"
            "計画暦日未達は dispatch_qty_shortfall に載せる。"
            "勤怠日付の自動拡張は行わない。"
        )
        if _ot_sim:
            _note_base += f" 残業シミュレーション適用: {_ot_sim}"
        shortage_payload: dict = {
            "format_version": 3,
            "source_json": str(path),
            "note": _note_base,
            "op_shortage": snap["op_shortage"],
            "as_shortage": snap["as_shortage"],
            "dispatch_qty_shortfall": dispatch_qty_shortfall,
            "remaining_tasks_at_calendar_end": _remaining_at_end,
            "stage3": s3_meta,
        }
        if isinstance(paths, dict):
            shortage_payload["production_plan"] = str(paths.get("production_plan") or "")
            shortage_payload["member_schedule"] = str(paths.get("member_schedule") or "")
        if _remaining_at_end:
            print(
                "[dispatch trial] 警告: 勤怠最終日まで未割当 "
                f"{len(_remaining_at_end)} 件（remaining_tasks_at_calendar_end を参照）",
                flush=True,
            )
        shortage_path.write_text(
            json.dumps(shortage_payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print("[dispatch trial] 不足情報JSONを書き出しました。", flush=True)
        try:
            from planning_core.dispatch_workspace import resolve_result_dispatch_table_output_dir

            _pip = (os.environ.get(pc.ENV_PLAN_INPUT_PATH) or "").strip()
            _out_dir = resolve_result_dispatch_table_output_dir(_pip)
            _written = Path(_out_dir) / pc.RESULT_DISPATCH_TABLE_JSON_FILENAME if _out_dir else None
            if _written is not None and _written.is_file() and _written.resolve() != path.resolve():
                path.write_text(_written.read_text(encoding="utf-8"), encoding="utf-8")
                print(f"[dispatch trial] 結果_配台表.json を入力パスへ同期: {_written} -> {path}", flush=True)
        except Exception as _sync_e:
            print(f"[dispatch trial] 結果_配台表.json 同期スキップ: {_sync_e}", flush=True)
        return 0, shortage_path
    except Exception as e:
        if type(e).__name__ == "PlanningValidationError":
            msg = str(e).strip() or "PlanningValidationError"
            print(msg, flush=True)
            try:
                pc._write_stage2_blocking_message(msg)
            except Exception:
                pass
            try:
                snap = pc.interactive_trial_shortages_snapshot()
                shortage_path.write_text(
                    json.dumps(
                        {
                            "format_version": 2,
                            "source_json": str(path),
                            "note": "validation failed before/during stage2",
                            "error": msg,
                            "op_shortage": snap["op_shortage"],
                            "as_shortage": snap["as_shortage"],
                            "dispatch_qty_shortfall": [],
                        },
                        ensure_ascii=False,
                        indent=2,
                    )
                    + "\n",
                    encoding="utf-8",
                )
            except Exception:
                pass
            return 3, shortage_path
        print(f"dispatch trial failed: {e}", flush=True)
        traceback.print_exc()
        return 1, None
    finally:
        _flush_dispatch_rule_trace_sidecar()
