# -*- coding: utf-8 -*-
"""回答済み納期ロック: 分類・実効完了日・試行順固定・入力日と目次の読込。"""
from datetime import date, datetime
from pathlib import Path

import pytest
from openpyxl import Workbook

from planning_core.core.answered_due_lock import (
    OutputSnapshot,
    classify_task_ids,
    completion_misses_shipping_date,
    effective_completion_by_task,
    exclude_protected_due_shift_ids,
    parse_input_stamp,
    pin_interrupt_trial_orders,
    slipped_protected_ids,
)
from planning_core.core.request_form_index_delivery_lookup import (
    load_index_delivery_raw_by_irai_no,
)
from planning_core.core.request_form_juchu_lookup import (
    load_juchu_input_date_raw_by_irai_no,
)


def _stamp(value, year=2026):
    return parse_input_stamp(value, year)


def test_interrupt_is_strictly_after_max_protected_input_date():
    classified = classify_task_ids(
        ["OLD", "MID", "NEW", "SAME", "NODATE"],
        delivery_raw_by_key={"OLD": "2026/4/20", "MID": "4/30"},
        input_raw_by_key={
            "OLD": "2026-04-01",
            "MID": "2026-04-10",
            "NEW": "2026-04-11",
            "SAME": "2026-04-10",
            "NODATE": "",
        },
        reference_year=2026,
    )
    assert classified.protected_ids == frozenset({"OLD", "MID"})
    assert classified.interrupt_ids == frozenset({"NEW"})
    assert not classified.warn_protected_input_date_missing


def test_same_day_with_clock_is_interrupt_only_when_both_have_time():
    later = _stamp(datetime(2026, 4, 10, 18, 0))
    earlier = _stamp(datetime(2026, 4, 10, 9, 0))
    date_only = _stamp("2026-04-10")
    assert later.has_time and earlier.has_time
    assert not date_only.has_time
    classified = classify_task_ids(
        ["P", "LATER", "DATEONLY"],
        delivery_raw_by_key={"P": datetime(2026, 5, 1)},
        input_raw_by_key={
            "P": datetime(2026, 4, 10, 9, 0),
            "LATER": datetime(2026, 4, 10, 18, 0),
            "DATEONLY": "2026-04-10",
        },
        reference_year=2026,
    )
    assert classified.interrupt_ids == frozenset({"LATER"})


def test_no_protected_input_date_does_not_demote():
    classified = classify_task_ids(
        ["P", "NEW"],
        delivery_raw_by_key={"P": "6/22"},
        input_raw_by_key={"NEW": "2026-08-01"},
        reference_year=2026,
    )
    assert classified.protected_ids == frozenset({"P"})
    assert classified.delivery_by_task_id["P"] == date(2026, 6, 22)
    assert classified.interrupt_ids == frozenset()
    assert classified.warn_protected_input_date_missing


def test_branch_task_uses_parent_delivery_and_input_date():
    classified = classify_task_ids(
        ["W7-22", "W7-22-1", "W8-1"],
        delivery_raw_by_key={"W7-22": "2026/07/15"},
        input_raw_by_key={"W7-22": "2026-07-01", "W8-1": "2026-07-02"},
        reference_year=2026,
    )
    assert "W7-22" in classified.protected_ids
    assert "W7-22-1" in classified.protected_ids
    assert classified.interrupt_ids == frozenset({"W8-1"})


def test_unparseable_delivery_is_not_protected():
    classified = classify_task_ids(
        ["X"],
        delivery_raw_by_key={"X": "未定"},
        input_raw_by_key={},
        reference_year=2026,
    )
    assert classified.protected_ids == frozenset()
    assert classified.interrupt_ids == frozenset()


def test_pin_moves_interrupts_behind_and_keeps_other_order():
    queue = [
        {"task_id": "NEW", "dispatch_trial_order": 1, "planning_sheet_row_seq": 1},
        {"task_id": "OLD", "dispatch_trial_order": 2, "planning_sheet_row_seq": 2},
        {"task_id": "OLD", "dispatch_trial_order": 3, "planning_sheet_row_seq": 3},
        {"task_id": "NEW", "dispatch_trial_order": 4, "planning_sheet_row_seq": 4},
    ]
    moved = pin_interrupt_trial_orders(queue, {"NEW"})
    assert moved == 2
    orders = [(t["task_id"], t["dispatch_trial_order"]) for t in queue]
    assert orders == [("OLD", 1), ("OLD", 2), ("NEW", 3), ("NEW", 4)]
    assert all(t["dispatch_trial_order_from_sheet"] == float(t["dispatch_trial_order"]) for t in queue)


def test_protected_excluded_from_due_shift():
    kept, skipped = exclude_protected_due_shift_ids(["A", "B", "A"], {"A"})
    assert kept == ["B"]
    assert skipped == ["A", "A"]


def test_effective_completion_is_later_of_process_complete_and_system_dispatch():
    rows = [
        {"依頼NO": "P", "加工完了日": "2026-07-16", "配台日": "2026-07-17", "当日配台数量": 600},
        {"依頼NO": "P", "加工完了日": "2026-07-16", "配台日": "2026-07-10", "当日配台数量": 0},
        {"依頼NO": "Q", "加工完了日": "2026-07-20", "配台日": "2026-07-18", "当日配台数量": 10},
    ]
    got = effective_completion_by_task(rows, 2026)
    assert got["P"] == date(2026, 7, 17)
    assert got["Q"] == date(2026, 7, 20)


def test_slip_is_one_calendar_day_or_more_versus_pinned_baseline():
    protected = {"P", "Q", "R"}
    pinned = {"P": date(2026, 7, 10), "Q": date(2026, 7, 10), "R": date(2026, 7, 12)}
    optimistic = {"P": date(2026, 7, 11), "Q": date(2026, 7, 10), "R": date(2026, 7, 9)}
    assert slipped_protected_ids(optimistic, pinned, protected) == ["P"]
    assert completion_misses_shipping_date(date(2026, 7, 17), date(2026, 7, 17))
    assert not completion_misses_shipping_date(date(2026, 7, 16), date(2026, 7, 17))
    assert completion_misses_shipping_date(None, date(2026, 7, 17))


def test_missing_pinned_baseline_is_not_a_slip():
    assert slipped_protected_ids(
        {"P": date(2026, 7, 20)},
        {},
        {"P"},
    ) == []


def test_juchu_input_date_and_index_delivery_are_read_only(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    juchu = tmp_path / "juchu.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "受注ﾌｧｲﾙ"
    ws.cell(3, 1, "依頼No")
    ws.cell(3, 5, "入力日")
    ws.cell(4, 1, "W7-22")
    ws.cell(4, 5, datetime(2026, 7, 1, 9, 30))
    wb.save(juchu)
    monkeypatch.setenv("PM_AI_REQUEST_FORM_JUCHU_FILE", str(juchu))
    raw = load_juchu_input_date_raw_by_irai_no()
    assert raw["W7-22"] == datetime(2026, 7, 1, 9, 30)

    original = tmp_path / "originals"
    original.mkdir()
    book = original / "req.xlsm"
    iwb = Workbook()
    index = iwb.active
    index.title = "目次"
    index.cell(1, 1, "加工依頼NO")
    index.cell(2, 1, "W7-22")
    index.cell(2, 11, "7/15")
    iwb.save(book)
    monkeypatch.setenv("PM_AI_REQUEST_FORM_ORIGINAL_DIR", str(original))
    before = set(original.iterdir())
    delivery = load_index_delivery_raw_by_irai_no()
    assert delivery["W7-22"] == "7/15"
    assert set(original.iterdir()) == before


def test_output_snapshot_restores_first_pass_files(tmp_path: Path):
    out = tmp_path / "output"
    out.mkdir()
    first = out / "計画260101.xlsx"
    first.write_bytes(b"first")
    (out / "結果_配台表.json").write_text("{\"rows\":[]}", encoding="utf-8")
    snap = OutputSnapshot()
    snap.capture([str(out)])
    second = out / "計画260102.xlsx"
    second.write_bytes(b"second")
    first.unlink()
    (out / "結果_配台表.json").write_text("{\"rows\":[1]}", encoding="utf-8")
    snap.restore()
    snap.cleanup()
    assert first.read_bytes() == b"first"
    assert not second.exists()
    assert (out / "結果_配台表.json").read_text(encoding="utf-8") == "{\"rows\":[]}"
