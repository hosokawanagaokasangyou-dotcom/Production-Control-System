# -*- coding: utf-8 -*-
"""段階1: 換算数量=0・実加工数=0・未加工=0 だが計画合計／受注数がある未完行は段階1を完了させない。"""

from __future__ import annotations

import pandas as pd
import pytest

from planning_core import _core as pc


def _row(tid, *, qty, actual, unp, plan_total=None, order_qty=None, flag="0:未完", machine="EC"):
    r = {
        pc.TASK_COL_TASK_ID: tid,
        pc.TASK_COL_MACHINE: machine,
        pc.TASK_COL_MACHINE_NAME: "EC機　湖南",
        pc.TASK_COL_QTY: qty,
        pc.TASK_COL_ACTUAL_DONE: actual,
        pc.TASK_COL_UNPROCESSED: unp,
        pc.TASK_COL_COMPLETION_FLAG: flag,
    }
    if plan_total is not None:
        r[pc.TASK_COL_PLAN_TOTAL] = plan_total
    if order_qty is not None:
        r[pc.TASK_COL_ORDER_QTY] = order_qty
    return r


def test_detects_zero_conversion_qty_with_plan_total():
    df = pd.DataFrame(
        [
            _row("W10-10", qty=0, actual=0, unp=0, plan_total=4500, order_qty=4500),
            _row("W10-11", qty=0, actual=0, unp=0, plan_total=6000, order_qty=6000, machine="検査"),
            _row("W10-7", qty=4500, actual=3300, unp=1200, plan_total=4500, order_qty=4500),
        ]
    )
    hits = pc._stage1_zero_conversion_qty_pending_rows(df)
    assert [(h["依頼NO"], h["工程名"]) for h in hits] == [("W10-10", "EC"), ("W10-11", "検査")]
    assert hits[0]["計画合計"] == 4500.0


def test_order_qty_only_is_detected():
    df = pd.DataFrame([_row("X1", qty=0, actual=0, unp=0, order_qty=1200)])
    assert len(pc._stage1_zero_conversion_qty_pending_rows(df)) == 1


def test_completed_or_no_planned_qty_is_ignored():
    df = pd.DataFrame(
        [
            _row("W10-6", qty=0, actual=0, unp=0, plan_total=4500, flag="1:完了"),
            _row("Z1", qty=0, actual=0, unp=0, plan_total=0, order_qty=0),
            _row("Z2", qty=0, actual=100, unp=0, plan_total=500),
        ]
    )
    assert pc._stage1_zero_conversion_qty_pending_rows(df) == []


def test_raise_blocks_stage1_with_task_ids_in_message():
    df = pd.DataFrame([_row("W10-12", qty=0, actual=0, unp=0, plan_total=4500)])
    with pytest.raises(pc.PlanningValidationError) as ei:
        pc._raise_if_stage1_zero_conversion_qty_rows(df)
    msg = str(ei.value)
    lines = msg.split("\n")
    assert lines[0].startswith(pc.STAGE1_ZERO_CONVERSION_QTY_BLOCK_HEADER)
    assert "段階2は実行できません" in lines[0]
    assert "  ・依頼NO W10-12 ／ 工程 EC（EC機　湖南） ／ 計画合計 4,500" in lines
    assert lines[-1].startswith("対処:")


def test_raise_noop_when_clean():
    df = pd.DataFrame([_row("W10-7", qty=4500, actual=0, unp=0, plan_total=4500)])
    pc._raise_if_stage1_zero_conversion_qty_rows(df)
